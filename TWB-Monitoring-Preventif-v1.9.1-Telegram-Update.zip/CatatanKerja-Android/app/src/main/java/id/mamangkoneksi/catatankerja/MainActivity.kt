package id.mamangkoneksi.catatankerja

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.util.Log
import android.view.View
import android.webkit.ConsoleMessage
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors
import org.json.JSONObject

class MainActivity : Activity() {
    private var web: WebView? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val fileRequest = 1201
    private val networkExecutor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        openApp()
    }

    @Suppress("SetJavaScriptEnabled")
    private fun openApp() {
        try {
            val view = WebView(this)
            web = view
            view.visibility = View.VISIBLE
            view.setBackgroundColor(android.graphics.Color.WHITE)

            view.settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                allowFileAccess = true
                allowContentAccess = true
                javaScriptCanOpenWindowsAutomatically = false
                setSupportMultipleWindows(false)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) safeBrowsingEnabled = true
            }

            view.addJavascriptInterface(FileBridge(), "AndroidFiles")
            view.addJavascriptInterface(TelegramBridge(), "AndroidTelegram")
            view.webChromeClient = object : WebChromeClient() {
                override fun onConsoleMessage(message: ConsoleMessage): Boolean {
                    Log.d("CatatanKerjaWeb", "${message.message()} -- ${message.sourceId()}:${message.lineNumber()}")
                    return true
                }

                override fun onShowFileChooser(
                    view: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?
                ): Boolean {
                    fileCallback?.onReceiveValue(null)
                    fileCallback = callback
                    // ACTION_OPEN_DOCUMENT gives WebView a reliable Android system file picker
                    // and supports files from Downloads, Drive providers, SD cards, etc.
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                        putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params?.mode == FileChooserParams.MODE_OPEN_MULTIPLE)
                    }
                    return try {
                        startActivityForResult(intent, fileRequest)
                        true
                    } catch (e: Exception) {
                        fileCallback?.onReceiveValue(null)
                        fileCallback = null
                        Toast.makeText(this@MainActivity, "Tidak dapat membuka pemilih file", Toast.LENGTH_LONG).show()
                        false
                    }
                }
            }

            view.webViewClient = object : WebViewClient() {
                override fun onReceivedError(v: WebView, request: WebResourceRequest, error: WebResourceError) {
                    super.onReceivedError(v, request, error)
                    if (request.isForMainFrame) {
                        Log.e("CatatanKerjaWeb", "Gagal memuat aplikasi: ${error.description}")
                        Toast.makeText(this@MainActivity, "Gagal membuka aplikasi. Coba tutup lalu buka kembali.", Toast.LENGTH_LONG).show()
                    }
                }

                override fun onRenderProcessGone(view: WebView, detail: android.webkit.RenderProcessGoneDetail): Boolean {
                    Log.e("CatatanKerjaWeb", "WebView renderer berhenti: crashed=${detail.didCrash()}")
                    this@MainActivity.web = null
                    (view.parent as? android.view.ViewGroup)?.removeView(view)
                    view.destroy()
                    openApp()
                    return true
                }
            }

            setContentView(view)
            view.loadUrl("file:///android_asset/index.html")
        } catch (e: Exception) {
            Log.e("CatatanKerja", "Gagal menjalankan aplikasi", e)
            Toast.makeText(this, "Aplikasi gagal dibuka: ${e.localizedMessage ?: "kesalahan sistem"}", Toast.LENGTH_LONG).show()
            finish()
        }
    }


    inner class TelegramBridge {
        @android.webkit.JavascriptInterface
        fun sendMessage(token: String, chatId: String, message: String) {
            networkExecutor.execute {
                var ok = false
                var result = "Tidak dapat menghubungi Telegram"
                var conn: HttpURLConnection? = null
                try {
                    require(token.matches(Regex("[0-9]+:[A-Za-z0-9_-]+"))) { "Format Bot Token tidak valid" }
                    require(chatId.isNotBlank()) { "Chat ID kosong" }
                    val connection = (URL("https://api.telegram.org/bot$token/sendMessage").openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 15000
                        readTimeout = 15000
                        doOutput = true
                        setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    }
                    conn = connection
                    val payload = JSONObject().put("chat_id", chatId).put("text", message.take(4000)).toString()
                    connection.outputStream.use { it.write(payload.toByteArray(StandardCharsets.UTF_8)) }
                    val code = connection.responseCode
                    val body = (if (code in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
                    val json = JSONObject(body)
                    ok = code in 200..299 && json.optBoolean("ok", false)
                    result = if (ok) "Pesan terkirim" else json.optString("description", "Telegram HTTP $code")
                } catch (e: Exception) {
                    result = e.localizedMessage ?: "Kesalahan jaringan"
                } finally {
                    conn?.disconnect()
                }
                val safe = JSONObject.quote(result)
                runOnUiThread { web?.evaluateJavascript("window.onTelegramResult && window.onTelegramResult($ok, $safe);", null) }
            }
        }
    }

    inner class FileBridge {
        @android.webkit.JavascriptInterface
        fun saveFile(base64: String, filename: String, mime: String) {
            runOnUiThread {
                try {
                    val bytes = Base64.decode(base64, Base64.DEFAULT)
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, filename)
                        put(MediaStore.Downloads.MIME_TYPE, mime)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: throw IllegalStateException("Tidak dapat membuat file")
                    contentResolver.openOutputStream(uri).use { stream: OutputStream? ->
                        stream?.write(bytes) ?: throw IllegalStateException("Tidak dapat menulis file")
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
                        contentResolver.update(uri, done, null, null)
                    }
                    Toast.makeText(this@MainActivity, "File tersimpan di folder Download", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Log.e("CatatanKerja", "Gagal menyimpan file", e)
                    Toast.makeText(this@MainActivity, "Gagal menyimpan file: ${e.message ?: "kesalahan"}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == fileRequest) {
            val results = if (resultCode == RESULT_OK) {
                data?.clipData?.let { clip -> Array(clip.itemCount) { i -> clip.getItemAt(i).uri } }
                    ?: data?.data?.let { arrayOf(it) }
            } else null
            fileCallback?.onReceiveValue(results)
            fileCallback = null
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        web?.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        fileCallback?.onReceiveValue(null)
        fileCallback = null
        web?.apply {
            stopLoading()
            removeJavascriptInterface("AndroidFiles")
            removeJavascriptInterface("AndroidTelegram")
            destroy()
        }
        web = null
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        AlertDialog.Builder(this)
            .setTitle("CATATAN KERJA")
            .setMessage("TERIMAH KASIH MAMANG KONEKSI @tawab hidayat")
            .setPositiveButton("Keluar") { _, _ -> finish() }
            .setNegativeButton("Batal", null)
            .show()
    }
}
