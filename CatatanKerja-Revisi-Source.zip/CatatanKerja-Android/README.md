# CATATAN KERJA — Android

Aplikasi Android untuk pencatatan Preventif, Complain Online, dan Monitoring UMD.

## Fitur
- Dashboard ringkasan Preventif, Complain Online, saldo UMD, dan grafik UMD.
- Preventif: GENSET, TOKO, CCTV/ALARM, LIFT, RTE/RTED; tambah, edit, hapus.
- GENSET, TOKO, CCTV/ALARM, dan LIFT dibatasi satu entri per kategori, per KODE TOKO + NAMA TOKO yang sama per bulan.
- RTE/RTED dibatasi satu entri per KODE TOKO + NAMA TOKO yang sama per minggu kalender (Senin–Minggu).
- Complain Online dengan semua field sebelumnya; tambah, edit, hapus.
- Monitoring UMD: catat saldo yang diterima, catat penggunaan, nominal, barang, foto barang, dan foto struk. Saldo tersisa dihitung otomatis.
- Foto penggunaan UMD diperkecil otomatis sebelum disimpan secara lokal.
- Pengaturan email Google dan tombol untuk membuka Google Drive. **Sinkronisasi/unggah otomatis ke Drive belum aktif**; fitur tersebut memerlukan konfigurasi OAuth/API Google.
- Laporan: ekspor Excel-compatible `.xls` dan `.csv`; data Preventif, Complain, saldo UMD, dan penggunaan UMD disertakan dalam ekspor.
- Data disimpan lokal pada perangkat melalui penyimpanan WebView. Ekspor cadangan secara berkala.
- Dialog keluar berisi: `TERIMAH KASIH MAMANG KONEKSI @tawab hidayat`.

## Build APK melalui GitHub Actions
1. Unggah/commit isi folder proyek ini ke root repositori GitHub (termasuk folder `.github/workflows`).
2. Buka tab **Actions**, pilih workflow **Build CATATAN KERJA APK**, lalu tekan **Run workflow**.
3. Tunggu sampai semua langkah berwarna hijau.
4. Buka hasil run dan unduh artifact **CatatanKerja-debug-apk**.
5. Ekstrak ZIP artifact, lalu pasang `app-debug.apk` di Android. Android mungkin meminta izin instalasi dari sumber tersebut.

Workflow menginstal Gradle pada runner, jadi file `gradlew` tidak diperlukan. APK tidak otomatis dibuat hanya dengan menambahkan `main.yml`; kode proyek dan konfigurasi Gradle juga harus berada di repositori.
