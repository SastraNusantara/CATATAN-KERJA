# CATATAN KERJA — Android

Aplikasi Android sederhana untuk pencatatan Preventif dan Complain Online.

## Fitur
- Dashboard dengan pintasan Preventif dan Complain Online.
- Preventif: GENSET, TOKO, CCTV/ALARM, LIFT, RTE/RTED; tambah, edit, hapus.
- GENSET, TOKO, CCTV/ALARM, LIFT dibatasi satu entri per kategori per bulan.
- RTE/RTED dibatasi satu entri per minggu kalender (Senin–Minggu).
- Complain Online dengan semua field yang diminta; tambah, edit, hapus.
- Laporan: ekspor file Excel-compatible `.xls` (SpreadsheetML) dan impor `.xls` / `.csv`.
- Data disimpan lokal pada perangkat melalui penyimpanan WebView.
- Dialog keluar berisi: `TERIMAH KASIH MAMANG KONEKSI @tawab hidayat`.

## Membuat APK
1. Unggah isi folder proyek ini ke repositori GitHub.
2. Buka tab **Actions**, pilih **Build CATATAN KERJA APK**, lalu tekan **Run workflow**.
3. Setelah workflow berhasil, buka hasil run dan unduh artifact **CatatanKerja-debug-apk**.
4. Ekstrak artifact, lalu pasang `app-debug.apk` di Android. Untuk memasang, Android mungkin meminta izin instalasi dari sumber tersebut.

Workflow menggunakan path APK yang sesuai dengan struktur proyek ini. APK belum disertakan karena build perlu dijalankan pada Android/Gradle build runner.


## Logo aplikasi
Logo monogram emas telah ditambahkan sebagai ikon launcher Android (mipmap) dan identitas pada header aplikasi.

Revisi: jadwal preventif bulanan per pasangan kode/nama toko untuk CCTV/ALARM, TOKO, LIFT, GENSET; RTE/RTED mingguan. Monitoring UMD lokal dengan saldo, pengeluaran, foto barang/struk dan grafik. Email Google Drive disimpan lokal; OAuth Drive belum dikonfigurasi.


## Logo TWB
Logo TWB digunakan sebagai ikon aplikasi dan watermark di pojok kanan atas header aplikasi.


## Dashboard TWB dan Monitoring Preventif
- Dashboard menampilkan persentase selesai bulanan untuk TOKO, GENSET, CCTV/ALARM, LIFT dan mingguan untuk RTE/RTED.
- Ringkasan jumlah toko selesai per kategori berdasarkan kode toko unik dan master toko.
- Menu About menyediakan impor data master toko CSV / Excel 2003 XML (.xls).
- Navigasi utama tetap di bagian bawah aplikasi.


## Pembaruan Master Toko (v1.2)
- Master toko mendukung tiga kolom: `KODE TOKO`, `NAMA TOKO`, dan `MAINTENANCE`.
- Dapat memilih beberapa file sekaligus untuk impor.
- Format impor: CSV, JSON, dan Excel 2003 XML (`.xls`/`.xml`). File Excel `.xlsx` perlu disimpan ulang sebagai CSV terlebih dahulu.
- Data dengan kode toko sama akan diperbarui, bukan digandakan.
- Nama maintenance tersedia sebagai pilihan pada Preventif (PIC) dan Complain (Maintenance/Supplier). Memilih kode toko akan mengisi otomatis nama toko dan maintenance jika tersedia.
- Master toko dapat diekspor kembali menjadi CSV.


## Update Master Toko
- Data master toko awal dimuat dari file NITIP DATA.xlsx (26 toko).
- Menu ABOUT menyediakan form tambah/update toko dengan KODE TOKO dan NAMA TOKO.
- Input PREVENTIF menggunakan KODE TOKO sebagai acuan; nama toko terisi otomatis dari Master Toko.
- Master toko tetap tersimpan secara lokal pada perangkat dan dapat diekspor/diimpor.


## Tampilan Glassmorphism v1.3
Tema visual diperbarui dengan latar gradasi gelap, efek kaca transparan/blur, kartu semi-transparan, navigasi kaca, dan aksen warna modern. Seluruh fitur dan struktur data master toko tetap dipertahankan.


## v1.3 — Enterprise Dark Premium
- Redesain antarmuka mengikuti mockup Enterprise Dark Premium navy, biru, dan emas.
- Dashboard dengan kartu statistik berwarna, welcome panel, dan monitoring preventif.
- Navigasi bawah: Dashboard, Preventif, Complain, Master, About.
- Master Toko dipisah menjadi halaman khusus dengan tambah/update, impor, dan ekspor.
- Fitur preventif, complain, laporan XLS/CSV, monitoring UMD, dan pengaturan tetap dipertahankan.
- Versi Android: 1.3 (versionCode 4).
