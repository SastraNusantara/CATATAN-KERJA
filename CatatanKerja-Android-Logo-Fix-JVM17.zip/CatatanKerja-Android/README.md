# CATATAN KERJA — Android

Aplikasi Android sederhana untuk pencatatan Preventif dan Complain Online.

## Fitur
- Dashboard dengan pintasan Preventif dan Complain Online.
- Preventif: GENSET, TOKO, CCTV/ALARM, LIFT, RTE/RTED; tambah, edit, hapus.
- GENSET, TOKO, CCTV/ALARM, LIFT dibatasi satu entri per kategori per bulan.
- RTE/RTED dibatasi satu entri per minggu kalender (Senin–Minggu).
- Complain Online dengan semua field yang diminta; tambah, edit, hapus.
- Laporan: ekspor file Excel-compatible `.xls` (SpreadsheetML) dan impor `.xls` / `.csv`.
- Data disimpan lokal pada perangkat melalui penyimpanan WebView.
- Dialog keluar berisi: `TERIMAH KASIH MAMANG KONEKSI @tawab hidayat`.

## Membuat APK
1. Unggah isi folder proyek ini ke repositori GitHub.
2. Buka tab **Actions**, pilih **Build CATATAN KERJA APK**, lalu tekan **Run workflow**.
3. Setelah workflow berhasil, buka hasil run dan unduh artifact **CatatanKerja-debug-apk**.
4. Ekstrak artifact, lalu pasang `app-debug.apk` di Android. Untuk memasang, Android mungkin meminta izin instalasi dari sumber tersebut.

Workflow menggunakan path APK yang sesuai dengan struktur proyek ini. APK belum disertakan karena build perlu dijalankan pada Android/Gradle build runner.


## Logo aplikasi
Logo monogram emas telah ditambahkan sebagai ikon launcher Android (mipmap) dan identitas pada header aplikasi.
