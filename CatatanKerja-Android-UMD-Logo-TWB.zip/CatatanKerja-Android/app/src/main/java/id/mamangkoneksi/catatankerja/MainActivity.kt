package id.mamangkoneksi.catatankerja

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.util.Log
import android.view.View
import android.webkit.ConsoleMessage
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.io.OutputStream

class MainActivity : Activity() {
    private var web: WebView? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val fileRequest = 1201

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        openApp()
    }

    @Suppress("SetJavaScriptEnabled")
    private fun openApp() {
        try {
            val view = WebView(this)
            web = view
            view.visibility = View.VISIBLE
            view.setBackgroundColor(android.graphics.Color.WHITE)

            view.settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                allowFileAccess = true
                allowContentAccess = true
                javaScriptCanOpenWindowsAutomatically = false
                setSupportMultipleWindows(false)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) safeBrowsingEnabled = true
            }

            view.addJavascriptInterface(FileBridge(), "AndroidFiles")
            view.webChromeClient = object : WebChromeClient() {
                override fun onConsoleMessage(message: ConsoleMessage): Boolean {
                    Log.d("CatatanKerjaWeb", "${message.message()} -- ${message.sourceId()}:${message.lineNumber()}")
                    return true
                }

                override fun onShowFileChooser(
                    view: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?
                ): Boolean {
                    fileCallback?.onReceiveValue(null)
                    fileCallback = callback
                    val intent = try {
                        params?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*" }
                    } catch (_: Exception) {
                        Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*" }
                    }
                    return try {
                        startActivityForResult(intent, fileRequest)
                        true
                    } catch (e: Exception) {
                        fileCallback?.onReceiveValue(null)
                        fileCallback = null
                        Toast.makeText(this@MainActivity, "Tidak dapat membuka pemilih file", Toast.LENGTH_LONG).show()
                        false
                    }
                }
            }

            view.webViewClient = object : WebViewClient() {
                override fun onReceivedError(v: WebView, request: WebResourceRequest, error: WebResourceError) {
                    super.onReceivedError(v, request, error)
                    if (request.isForMainFrame) {
                        Log.e("CatatanKerjaWeb", "Gagal memuat aplikasi: ${error.description}")
                        Toast.makeText(this@MainActivity, "Gagal membuka aplikasi. Coba tutup lalu buka kembali.", Toast.LENGTH_LONG).show()
                    }
                }

                override fun onRenderProcessGone(view: WebView, detail: android.webkit.RenderProcessGoneDetail): Boolean {
                    Log.e("CatatanKerjaWeb", "WebView renderer berhenti: crashed=${detail.didCrash()}")
                    this@MainActivity.web = null
                    (view.parent as? android.view.ViewGroup)?.removeView(view)
                    view.destroy()
                    openApp()
                    return true
                }
            }

            setContentView(view)
            view.loadUrl("file:///android_asset/index.html")
        } catch (e: Exception) {
            Log.e("CatatanKerja", "Gagal menjalankan aplikasi", e)
            Toast.makeText(this, "Aplikasi gagal dibuka: ${e.localizedMessage ?: "kesalahan sistem"}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    inner class FileBridge {
        @android.webkit.JavascriptInterface
        fun saveFile(base64: String, filename: String, mime: String) {
            runOnUiThread {
                try {
                    val bytes = Base64.decode(base64, Base64.DEFAULT)
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, filename)
                        put(MediaStore.Downloads.MIME_TYPE, mime)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: throw IllegalStateException("Tidak dapat membuat file")
                    contentResolver.openOutputStream(uri).use { stream: OutputStream? ->
                        stream?.write(bytes) ?: throw IllegalStateException("Tidak dapat menulis file")
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
                        contentResolver.update(uri, done, null, null)
                    }
                    Toast.makeText(this@MainActivity, "File tersimpan di folder Download", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Log.e("CatatanKerja", "Gagal menyimpan file", e)
                    Toast.makeText(this@MainActivity, "Gagal menyimpan file: ${e.message ?: "kesalahan"}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == fileRequest) {
            val results = if (resultCode == RESULT_OK) {
                data?.clipData?.let { clip -> Array(clip.itemCount) { i -> clip.getItemAt(i).uri } }
                    ?: data?.data?.let { arrayOf(it) }
            } else null
            fileCallback?.onReceiveValue(results)
            fileCallback = null
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        web?.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        fileCallback?.onReceiveValue(null)
        fileCallback = null
        web?.apply {
            stopLoading()
            removeJavascriptInterface("AndroidFiles")
            destroy()
        }
        web = null
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        AlertDialog.Builder(this)
            .setTitle("CATATAN KERJA")
            .setMessage("TERIMAH KASIH MAMANG KONEKSI @tawab hidayat")
            .setPositiveButton("Keluar") { _, _ -> finish() }
            .setNegativeButton("Batal", null)
            .show()
    }
}
